---
name: Sattvi
colors:
  surface: '#fcf9f4'
  surface-dim: '#dcdad5'
  surface-bright: '#fcf9f4'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ee'
  surface-container: '#f0ede9'
  surface-container-high: '#eae8e3'
  surface-container-highest: '#e5e2dd'
  on-surface: '#1c1c19'
  on-surface-variant: '#434843'
  inverse-surface: '#31302d'
  inverse-on-surface: '#f3f0eb'
  outline: '#737873'
  outline-variant: '#c3c8c1'
  surface-tint: '#4f6354'
  primary: '#475b4c'
  on-primary: '#ffffff'
  primary-container: '#5f7464'
  on-primary-container: '#e2f9e5'
  inverse-primary: '#b5ccb9'
  secondary: '#8b4e3d'
  on-secondary: '#ffffff'
  secondary-container: '#fdad98'
  on-secondary-container: '#783f2f'
  tertiary: '#575753'
  on-tertiary: '#ffffff'
  tertiary-container: '#6f6f6b'
  on-tertiary-container: '#f5f3ee'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e8d5'
  primary-fixed-dim: '#b5ccb9'
  on-primary-fixed: '#0c1f13'
  on-primary-fixed-variant: '#374b3d'
  secondary-fixed: '#ffdbd1'
  secondary-fixed-dim: '#ffb5a1'
  on-secondary-fixed: '#380d03'
  on-secondary-fixed-variant: '#6f3728'
  tertiary-fixed: '#e4e2dd'
  tertiary-fixed-dim: '#c8c6c2'
  on-tertiary-fixed: '#1b1c19'
  on-tertiary-fixed-variant: '#474744'
  background: '#fcf9f4'
  on-background: '#1c1c19'
  surface-variant: '#e5e2dd'
typography:
  display-lg:
    fontFamily: EB Garamond
    fontSize: 48px
    fontWeight: '500'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: EB Garamond
    fontSize: 36px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-md:
    fontFamily: EB Garamond
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  headline-sm:
    fontFamily: EB Garamond
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Manrope
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Manrope
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style
The design system is rooted in the philosophy of "Sattva"—purity, harmony, and balance. It is designed for a conscious audience seeking natural wellness through high-quality, organic products. The visual language avoids the frantic energy of traditional e-commerce, opting instead for a serene, editorial experience that evokes the feeling of a quiet morning in nature.

The style is **Minimalist with Tactile Organicism**. It leverages expansive whitespace to denote luxury and clarity, while utilizing subtle shadows and soft geometry to prevent the interface from feeling cold or clinical. Every interaction should feel intentional, grounded, and trustworthy.

## Colors
The palette is derived from natural elements: moss, clay, and parchment. 

- **Primary (Sage Green):** Used for key actions, active states, and brand signifiers. It represents growth and serenity.
- **Secondary (Soft Terracotta):** Used for accents, secondary buttons, and highlighting organic ingredients. It adds human warmth to the digital experience.
- **Tertiary (Creamy White):** The primary background color. Unlike pure white, this off-white tone reduces eye strain and feels more like natural paper.
- **Neutral (Charcoal Olive):** A very dark, warm grey used for typography and deep borders to ensure high legibility without the harshness of pure black.

## Typography
The typographic scale emphasizes a "high-low" contrast between the classical elegance of **EB Garamond** and the modern precision of **Manrope**.

- **Headlines:** Use EB Garamond for all editorial headers and product titles. Use slightly tighter letter-spacing for larger sizes to maintain a premium, custom-type feel.
- **Body & UI:** Use Manrope for all functional text, product descriptions, and navigational elements. Its balanced proportions ensure clarity and a contemporary feel.
- **Labels:** Small labels and captions use Manrope in a semi-bold weight with increased letter-spacing and uppercase styling to provide clear hierarchy in a minimal layout.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy on desktop to preserve white space and an editorial feel, transitioning to a fluid model on mobile.

- **The 8px Grid:** All internal component spacing (padding/margins) must be multiples of 8px.
- **Rhythm:** Utilize generous vertical spacing (`section-gap`) between content blocks to allow the design to "breathe." 
- **Desktop:** 12-column grid with a 1280px max-width, centered.
- **Mobile:** 4-column grid with 20px side margins. Content should stack vertically, prioritizing large, high-quality imagery of natural textures.

## Elevation & Depth
In keeping with the organic theme, this design system avoids harsh dropshadows. Depth is created through **Tonal Layering** and **Ambient Diffusion**.

- **Surface Levels:** The base layer is the Tertiary (Cream). Cards and containers use a pure white surface or a very subtle tint of Sage to indicate elevation.
- **Shadows:** Use extremely soft, long-spread shadows with low opacity (3-5%) and a slight color tint of the Primary color. This mimics the soft shadow cast by a leaf or natural object in sunlight.
- **Depth Cues:** Depth is primarily communicated through overlapping elements (e.g., an image slightly overlapping a text box) rather than traditional z-axis elevation.

## Shapes
The shape language is inspired by river stones and botanical curves. 

- **Containers:** Standard cards and containers use a 0.5rem (8px) radius to feel soft but professional.
- **Organic Accents:** For image masks or large "Hero" decorative elements, use irregular, organic blobs or asymmetric radii (e.g., `rounded-tl-[100px] rounded-br-[100px]`) to break the rigidity of the digital grid.
- **Buttons:** Buttons should be fully rounded (pill-shaped) to invite interaction and feel comfortable to the touch.

## Components
Consistent execution of components is vital to maintaining the serene brand personality.

- **Buttons:** Primary buttons are Sage Green with white text; secondary buttons are Ghost-style with a Terracotta border. All buttons use the Pill shape.
- **Input Fields:** Use a minimal approach—bottom borders only or very light-grey outlines. Focus states should gently transition the border to Sage Green.
- **Cards:** Product cards should have zero or very subtle borders. Use the "Ambient Shadow" defined in Elevation for a lifted effect on hover.
- **Chips/Tags:** Used for "Organic," "Vegan," or "Fair Trade" certifications. Use a very light Sage background with dark Sage text.
- **Lists:** Use custom icons for list bullets (e.g., a small leaf or dot) rather than standard browser defaults.
- **Product Gallery:** Images should always have a slight rounded corner (8px) to match the container language.